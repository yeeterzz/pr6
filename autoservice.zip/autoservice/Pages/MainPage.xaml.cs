﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace autoservice.Pages
{
    /// <summary>
    /// Логика взаимодействия для MainPage.xaml
    /// </summary>
    public partial class MainPage : Page
    {
        static KeyValuePair<string, Func<Page>> Nav(string title, Func<Page> factory)
        {
            return new KeyValuePair<string, Func<Page>>(title, factory);
        }

        public MainPage()
        {
            InitializeComponent();
            string role = App.CurrentUser.Roles.Name;
            FioText.Text = App.CurrentUser.FullName;
            RoleText.Text = role;

            var items = new List<KeyValuePair<string, Func<Page>>>();
            if (role == "Администратор")
            {
                items.Add(Nav("Клиенты", () => new ClientsPage()));
                items.Add(Nav("Автомобили", () => new CarsPage()));
                items.Add(Nav("Услуги", () => new ServicesPage()));
                items.Add(Nav("Заказы", () => new OrdersPage()));
                items.Add(Nav("Пользователи", () => new UsersPage()));
            }
            else if (role == "Мастер")
            {
                items.Add(Nav("Заказы", () => new OrdersPage()));
                items.Add(Nav("Услуги", () => new ServicesPage()));
            }
            else
            {
                items.Add(Nav("Мои автомобили", () => new CarsPage()));
                items.Add(Nav("Мои заказы", () => new OrdersPage()));
            }

            foreach (var item in items)
            {
                var factory = item.Value;
                var b = new Button
                {
                    Content = item.Key,
                    Padding = new Thickness(14, 4, 14, 4),
                    Margin = new Thickness(0, 0, 8, 0)
                };
                b.Click += (s, ev) => ContentFrame.Navigate(factory());
                NavPanel.Children.Add(b);
            }
            ContentFrame.Navigate(items[0].Value());
        }

        private void Logout_Click(object sender, RoutedEventArgs e)
        {
            App.CurrentUser = null;
            NavigationService.Navigate(new LoginPage());
        }
    }
}
