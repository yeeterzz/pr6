﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using autoservice.Models;

namespace autoservice.Pages
{
    /// <summary>
    /// Логика взаимодействия для OrdersPage.xaml
    /// </summary>
    public partial class OrdersPage : Page
    {
        public OrdersPage()
        {
            InitializeComponent();
            string role = App.CurrentUser.Roles.Name;
            BAdd.Visibility = BDelete.Visibility = role == "Администратор" ? Visibility.Visible : Visibility.Collapsed;
            BEdit.Visibility = role != "Клиент" ? Visibility.Visible : Visibility.Collapsed;
            if (role == "Клиент") TBTitle.Text = "Мои заказы";
            LoadData();
            IsVisibleChanged += (s, e) => { if ((bool)e.NewValue) LoadData(); };
        }

        void LoadData()
        {
            string role = App.CurrentUser.Roles.Name;
            int uid = App.CurrentUser.Id;
            if (role == "Мастер")
                DGOrders.ItemsSource = App.DB.Orders.Where(x => x.MasterId == uid).ToList();
            else if (role == "Клиент")
                DGOrders.ItemsSource = App.DB.Orders.Where(x => x.cars.Clients.UserId == uid).ToList();
            else
                DGOrders.ItemsSource = App.DB.Orders.ToList();
        }

        private void BAdd_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new OrderEditPage(new Orders { OrderDate = DateTime.Today, Status = "Новый" }));
        }

        private void BEdit_Click(object sender, RoutedEventArgs e)
        {
            var selected = DGOrders.SelectedItem as Orders;
            if (selected == null)
            {
                MessageBox.Show("Выберите запись!");
                return;
            }
            NavigationService.Navigate(new OrderEditPage(selected));
        }

        private void BDelete_Click(object sender, RoutedEventArgs e)
        {
            var selected = DGOrders.SelectedItem as Orders;
            if (selected == null)
            {
                MessageBox.Show("Выберите запись!");
                return;
            }

            if (MessageBox.Show("Удалить выбранную запись?", "Подтверждение",
                    MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes) return;
            try
            {
                App.DB.Orders.Remove(selected);
                App.DB.SaveChanges();
            }
            catch (Exception)
            {
                App.DB.Entry(selected).Reload();
                MessageBox.Show("Запись нельзя удалить: она связана с другими данными.");
            }
            LoadData();
        }
    }
}
