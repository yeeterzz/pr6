﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using autoservice.Models;

namespace autoservice.Pages
{
    /// <summary>
    /// Логика взаимодействия для CarEditPage.xaml
    /// </summary>
    public partial class CarEditPage : Page
    {
        cars contextCar;

        public CarEditPage(cars item)
        {
            InitializeComponent();
            contextCar = item;
            CBClient.ItemsSource = App.DB.Clients.ToList();
            DataContext = contextCar;
        }

        private void BSave_Click(object sender, RoutedEventArgs e)
        {
            string errorMessage = "";
            if (contextCar.Clients == null)
                errorMessage += "Выберите владельца\n";
            if (string.IsNullOrWhiteSpace(contextCar.Brand))
                errorMessage += "Заполните марку\n";
            if (string.IsNullOrWhiteSpace(contextCar.Model))
                errorMessage += "Заполните модель\n";
            if (contextCar.ReleaseYear < 1950 || contextCar.ReleaseYear > DateTime.Now.Year + 1)
                errorMessage += "Год выпуска должен быть в диапазоне 1950 – " + (DateTime.Now.Year + 1) + "\n";
            if (string.IsNullOrWhiteSpace(contextCar.PlateNumber))
                errorMessage += "Заполните гос. номер\n";
            if (!string.IsNullOrWhiteSpace(errorMessage))
            {
                MessageBox.Show(errorMessage);
                return;
            }

            try
            {
                if (contextCar.Id == 0)
                    App.DB.cars.Add(contextCar);
                App.DB.SaveChanges();
                NavigationService.GoBack();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Не удалось сохранить запись: " + ex.GetBaseException().Message);
            }
        }

        private void BCancel_Click(object sender, RoutedEventArgs e)
        {
            App.Discard(contextCar);
            NavigationService.GoBack();
        }
    }
}
