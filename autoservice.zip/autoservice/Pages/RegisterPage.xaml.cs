﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using autoservice.Models;

namespace autoservice.Pages
{
    /// <summary>
    /// Логика взаимодействия для RegisterPage.xaml
    /// </summary>
    public partial class RegisterPage : Page
    {
        public RegisterPage()
        {
            InitializeComponent();
        }

        void Register_Button_Click(object sender, RoutedEventArgs e)
        {
            string fio = FioBox.Text, login = LoginBox.Text;
            string p1 = PassBox.Password, p2 = Pass2box.Password;

            if
                (fio == "" || login == "" || p1 == "" || p2 == "")
            {
                MessageBox.Show("Заполните все поля");
                return;
            }
            if (p1 != p2)
            {
                MessageBox.Show("Пароли не совпадают");
                return;
            }
            {
                var db = new AutoServiceAmirEntities();
                {
                    if (db.Users.Any(u => u.Login == login))
                    {
                        MessageBox.Show("Такой логин уже существует");
                        return;
                    }
                    int roleId = db.Roles.First(r => r.Name == "Клиент").Id;
                    var user = new Users
                    { Login = login, Password = p1, FullName = fio, RoleId = roleId };
                    db.Users.Add(user);
                    db.SaveChanges();

                    db.Clients.Add(new Clients { FullName = fio, UserId = user.Id });
                    db.SaveChanges();
                }
                MessageBox.Show("Успешная регистрация");
                NavigationService.Navigate(new LoginPage());
            }
        }

        void Back_Button_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new LoginPage());
        }
    }
}
