﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using autoservice.Models;

namespace autoservice.Pages
{
    /// <summary>
    /// Логика взаимодействия для ServiceEditPage.xaml
    /// </summary>
    public partial class ServiceEditPage : Page
    {
        Services contextService;

        public ServiceEditPage(Services item)
        {
            InitializeComponent();
            contextService = item;

            DataContext = contextService;
        }

        private void BSave_Click(object sender, RoutedEventArgs e)
        {
            string errorMessage = "";
            if (string.IsNullOrWhiteSpace(contextService.Name))
                errorMessage += "Заполните название\n";
            if (contextService.Price <= 0)
                errorMessage += "Цена должна быть больше 0\n";
            if (contextService.DurationMin <= 0)
                errorMessage += "Длительность должна быть больше 0\n";
            if (!string.IsNullOrWhiteSpace(errorMessage))
            {
                MessageBox.Show(errorMessage);
                return;
            }

            try
            {
                if (contextService.Id == 0)
                    App.DB.Services.Add(contextService);
                App.DB.SaveChanges();
                NavigationService.GoBack();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Не удалось сохранить запись: " + ex.GetBaseException().Message);
            }
        }

        private void BCancel_Click(object sender, RoutedEventArgs e)
        {
            App.Discard(contextService);
            NavigationService.GoBack();
        }
    }
}
