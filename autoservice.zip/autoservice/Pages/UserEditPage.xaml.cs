﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using autoservice.Models;

namespace autoservice.Pages
{
    /// <summary>
    /// Логика взаимодействия для UserEditPage.xaml
    /// </summary>
    public partial class UserEditPage : Page
    {
        Users contextUser;

        public UserEditPage(Users item)
        {
            InitializeComponent();
            contextUser = item;
            CBRole.ItemsSource = App.DB.Roles.ToList();
            DataContext = contextUser;
        }

        private void BSave_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(contextUser.Login))
            if (string.IsNullOrWhiteSpace(contextUser.Password))
            if (string.IsNullOrWhiteSpace(contextUser.FullName))
            if (contextUser.Roles == null)
            {
                MessageBox.Show("Заполните все поля!");
                return;
            }
            {
                if (contextUser.Id == 0)
                    App.DB.Users.Add(contextUser);
                App.DB.SaveChanges();
                NavigationService.GoBack();
            }
        }

        private void BCancel_Click(object sender, RoutedEventArgs e)
        {
            App.Discard(contextUser);
            NavigationService.GoBack();
        }
    }
}
