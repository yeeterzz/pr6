﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace autoservice.Pages
{
    /// <summary>
    /// Логика взаимодействия для ClientEditPage.xaml
    /// </summary>
    public partial class ClientEditPage : Page
    {
        Models.Clients contextClient;

        public ClientEditPage(Models.Clients item)
        {
            InitializeComponent();
            contextClient = item;
            CBUser.ItemsSource = App.DB.Users.Where(x => x.Roles.Name == "Клиент").ToList();
            DataContext = contextClient;
        }

        private void BSave_Click(object sender, RoutedEventArgs e)
        {
            string errorMessage = "";
            if (string.IsNullOrWhiteSpace(contextClient.FullName))
                errorMessage += "Заполните ФИО";
            if (!string.IsNullOrWhiteSpace(errorMessage))
            {
                MessageBox.Show(errorMessage);
                return;
            }

            try
            {
                if (contextClient.Id == 0)
                App.DB.Clients.Add(contextClient);
                App.DB.SaveChanges();
                NavigationService.GoBack();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Не удалось сохранить запись: " + ex.GetBaseException().Message);
            }
        }

        private void BCancel_Click(object sender, RoutedEventArgs e)
        {
            App.Discard(contextClient);
            NavigationService.GoBack();
        }
    }
}
