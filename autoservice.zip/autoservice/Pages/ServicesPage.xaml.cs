﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using autoservice.Models;

namespace autoservice.Pages
{
    /// <summary>
    /// Логика взаимодействия для ServicesPage.xaml
    /// </summary>
    public partial class ServicesPage : Page
    {
        public ServicesPage()
        {
            InitializeComponent();
            bool admin = App.CurrentUser.Roles.Name == "Администратор";
            BAdd.Visibility = BEdit.Visibility = BDelete.Visibility = admin ? Visibility.Visible : Visibility.Collapsed;
            LoadData();
            IsVisibleChanged += (s, e) => { if ((bool)e.NewValue) LoadData(); };
        }

        void LoadData()
        {
            DGServices.ItemsSource = App.DB.Services.ToList();
        }

        private void BAdd_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new ServiceEditPage(new Services()));
        }

        private void BEdit_Click(object sender, RoutedEventArgs e)
        {
            var selected = DGServices.SelectedItem as Services;
            if (selected == null)
            {
                MessageBox.Show("Выберите запись!");
                return;
            }
            NavigationService.Navigate(new ServiceEditPage(selected));
        }

        private void BDelete_Click(object sender, RoutedEventArgs e)
        {
            var selected = DGServices.SelectedItem as Services;
            if (selected == null)
            {
                MessageBox.Show("Выберите запись!");
                return;
            }

            if (MessageBox.Show("Удалить выбранную запись?", "Подтверждение",
                    MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes) return;
            try
            {
                App.DB.Services.Remove(selected);
                App.DB.SaveChanges();
            }
            catch (Exception)
            {
                App.DB.Entry(selected).Reload();
                MessageBox.Show("Запись нельзя удалить: она связана с другими данными.");
            }
            LoadData();
        }
    }
}
