﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace autoservice.Pages
{
    /// <summary>
    /// Логика взаимодействия для LoginPage.xaml
    /// </summary>
    public partial class LoginPage : Page
    {
        public LoginPage()
        {
            InitializeComponent();
        }

        private void Login_Click(object sender, RoutedEventArgs e)
        {
                {
                    string Login = LoginBox.Text;
                    string Password = Passbox.Password;
                    App.CurrentUser = App.DB.Users.FirstOrDefault(x => x.Login == Login && x.Password == Password);
                    if (App.CurrentUser != null)
                    {
                        NavigationService.Navigate(new MainPage());

                    }
                    else {
                        MessageBox.Show("Неверный логин или пароль");
                    return;
                    } 

                }
        }

        void Register_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new Pages.RegisterPage());
        }
    }
}
