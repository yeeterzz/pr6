﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using autoservice.Models;

namespace autoservice.Pages
{
    /// <summary>
    /// Логика взаимодействия для UsersPage.xaml
    /// </summary>
    public partial class UsersPage : Page
    {
        public UsersPage()
        {
            InitializeComponent();

            LoadData();
            IsVisibleChanged += (s, e) => { if ((bool)e.NewValue) LoadData(); };
        }

        void LoadData()
        {
            DGUsers.ItemsSource = App.DB.Users.ToList();
        }

        private void BAdd_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new UserEditPage(new Users()));
        }

        private void BEdit_Click(object sender, RoutedEventArgs e)
        {
            var selected = DGUsers.SelectedItem as Users;
            if (selected == null)
            {
                MessageBox.Show("Выберите запись!");
                return;
            }
            NavigationService.Navigate(new UserEditPage(selected));
        }

        private void BDelete_Click(object sender, RoutedEventArgs e)
        {
            var selected = DGUsers.SelectedItem as Users;
            if (selected == null)
            {
                MessageBox.Show("Выберите запись!");
                return;
            }
            if (selected.Id == App.CurrentUser.Id)
            {
                MessageBox.Show("Нельзя удалить собственную учётную запись");
                return;
            }
            if (MessageBox.Show("Удалить выбранную запись?", "Подтверждение",
                    MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes) return;

            {
                App.DB.Users.Remove(selected);
                App.DB.SaveChanges();
            }
            {
                LoadData();
            }
        }
    }
}
