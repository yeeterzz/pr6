﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using autoservice.Models;

namespace autoservice.Pages
{
    /// <summary>
    /// Логика взаимодействия для ClientsPage.xaml
    /// </summary>
    public partial class ClientsPage : Page
    {
        public ClientsPage()
        {
            InitializeComponent();

            LoadData();
            IsVisibleChanged += (s, e) => { if ((bool)e.NewValue) LoadData(); };
        }

        void LoadData()
        {
            DGClients.ItemsSource = App.DB.Clients.ToList();
        }

        private void BAdd_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new ClientEditPage(new Clients()));
        }

        private void BEdit_Click(object sender, RoutedEventArgs e)
        {
            var selected = DGClients.SelectedItem as Clients;
            if (selected == null)
            {
                MessageBox.Show("Выберите запись!");
                return;
            }
            NavigationService.Navigate(new ClientEditPage(selected));
        }

        private void BDelete_Click(object sender, RoutedEventArgs e)
        {
            var selected = DGClients.SelectedItem as Clients;
            if (selected == null)
            {
                MessageBox.Show("Выберите запись!");
                return;
            }

            if (MessageBox.Show("Удалить выбранную запись?", "Подтверждение",
                    MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes) return;
            try
            {
                App.DB.Clients.Remove(selected);
                App.DB.SaveChanges();
            }
            catch (Exception)
            {
                App.DB.Entry(selected).Reload();
                MessageBox.Show("Запись нельзя удалить: она связана с другими данными.");
            }
            LoadData();
        }
    }
}
