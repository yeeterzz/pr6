﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using autoservice.Models;

namespace autoservice.Pages
{
    /// <summary>
    /// Логика взаимодействия для OrderEditPage.xaml
    /// </summary>
    public partial class OrderEditPage : Page
    {
        Orders contextOrder;

        public OrderEditPage(Orders item)
        {
            InitializeComponent();
            contextOrder = item;
            CBCar.ItemsSource = App.DB.cars.ToList();
            CBService.ItemsSource = App.DB.Services.ToList();
            CBMaster.ItemsSource = App.DB.Users.Where(x => x.Roles.Name == "Мастер").ToList();

            if (App.CurrentUser.Roles.Name == "Мастер")
            {
                CBCar.IsEnabled = CBService.IsEnabled = CBMaster.IsEnabled = DPDate.IsEnabled = false;
            }
            DataContext = contextOrder;
        }

        private void BSave_Click(object sender, RoutedEventArgs e)
        {
            string errorMessage = "";
            if (contextOrder.cars == null)
                errorMessage += "Выберите автомобиль";
            if (contextOrder.Services == null)
                errorMessage += "Выберите услугу";
            if (string.IsNullOrWhiteSpace(contextOrder.Status))
                errorMessage += "Выберите статус";
            if (!string.IsNullOrWhiteSpace(errorMessage))
            {
                MessageBox.Show(errorMessage);
                return;
            }

            try
            {
                if (contextOrder.Id == 0)
                    App.DB.Orders.Add(contextOrder);
                App.DB.SaveChanges();
                NavigationService.GoBack();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Не удалось сохранить запись: " + ex.GetBaseException().Message);
            }
        }

        private void BCancel_Click(object sender, RoutedEventArgs e)
        {
            App.Discard(contextOrder);
            NavigationService.GoBack();
        }
    }
}
