﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using autoservice.Models;
using System.Data.Entity;

namespace autoservice
{
    /// <summary>
    /// Логика взаимодействия для App.xaml
    /// </summary>
    public partial class App : Application
    {
        public static AutoServiceAmirEntities DB = new AutoServiceAmirEntities();
        public static Users CurrentUser;

        public static void Discard(object entity)
        {
            var entry = DB.Entry(entity);
            if (entry.State == EntityState.Added) entry.State = EntityState.Detached;
            else if (entry.State != EntityState.Detached) entry.Reload();
        }
    }
}
